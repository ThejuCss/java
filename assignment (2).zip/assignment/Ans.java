import java.util.*;
abstract class Shape{
 abstract  void RectangleArea(int length,int breadth);
 abstract  void SquareArea(int side);
 abstract void CircleArea(int radius);
}
class Area{
  void RectangleArea(int length,int breadth){
  int area=length*breadth;
  System.out.println(area);
  }
  void SquareArea(int side)
  {
  int area=side*side;
  System.out.println(area);
  }
  void CircleArea(int radius)
  {
  double area=3.14*radius*radius;
  System.out.println(area);
  }
  public static void main(String[] args){
    int length,breadth,side,radius;
    Area area=new Area();
    Scanner sc=new Scanner(System.in);
    System.out.println("�nter length of rectangle");
    length=sc.nextInt();
    System.out.println("�nter breadth of rectangle");
    breadth=sc.nextInt();
    area.RectangleArea(length, breadth);
    System.out.println("�nter side of square");
    side=sc.nextInt();
    area.SquareArea(side);
    System.out.println("�nter radius of circle");
    radius=sc.nextInt();
    area.CircleArea(radius);
      
     
  }
}