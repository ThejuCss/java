abstract class Animal{
  public abstract void cat();
  public abstract void dog();
}
class Cat extends Animal{
 public void cat()
 {
  System.out.println("cat meow");
 }
 public void dog(){
 }
}
 class Dog extends Animal{
 public void dog()
 {
   System.out.println("dog bark");
 }
 public void cat()
{
}
}
public class Sound{
 public static void main(String args[])
 {
   Cat c1=new Cat();
   c1.cat();
   Dog d1=new Dog();
   d1.dog();
 }
}