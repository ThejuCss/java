class Teacher {
   String designation = "Teacher";
   String collegeName = "aditya";
   public String getDesignation() {
	return designation;
   }
   public void setDesignation(String designation) {
	this.designation = designation;
   }
   public String getCollegeName() {
	return collegeName;
   }
   public void setCollegeName(String collegeName) {
	this.collegeName = collegeName;
   }
   void work(){
	System.out.println("Teaching");
   }
}

 class SubjectTeacher extends Teacher{
   String Subject = "Physics";
   public static void main(String args[]){
	SubjectTeacher st = new SubjectTeacher();
	System.out.println(st.getCollegeName());
	System.out.println(st.getDesignation());
        st.work();
	System.out.println(st.Subject);
	
   }
}