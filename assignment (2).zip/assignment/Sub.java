abstract class Teacher{
  public abstract void a_method();
  public void b_method(){
  System.out.println("This is normal method of abstact class");
  }
  public Teacher(){
  System.out.println("This is Constructor of abstract class");
  } 
}
     
     class Student extends Teacher{
     public void a_method(){
     System.out.println("This is abstract method");
     }
}

public class Sub{
  public static void main(String args[]){
   Student sc=new Student();
    sc.a_method();
    sc.b_method();
  }
}