import java.util.ArrayList;
import java.util.List;

public class Employee {

 private String name;
 private String dateOfJoining;
 private String address;
 public String getName()
 {
     return name;
 }
 public void setName(String name) 
 {
     this.name = name;
     
 }
 public String getdateOfJoining() 
 {
     return dateOfJoining;
     
 }
 public void setdateOfJoining(String dateOfJoining) 
 {
     this.dateOfJoining = dateOfJoining;
 }
 public String getaddress()
 {
     return address;
     
 }
 public void setaddress(String address)
 {
     this.address = address;
     
 }
 
 public Employee(String name, String dateOfJoining,String address) {
 this.name = name;
 this.dateOfJoining = dateOfJoining;
 this.address = address;
 }
}
public class Solution18{
public static void main(String[] args) {
    List<Employee> emp = new ArrayList<Employee>();
    emp.add(new Employee("theju", "5-9-12",  "chennai"));
    emp.add(new Employee("Smith", "6-9-12",  "chennai"));
    emp.add(new Employee("James", "15-9-12", "chennai"));
   
    System.out.printf("%10s %30s %20s", "name", "dateOfJoining", "address");
    System.out.println();
   System.out.println("-----------------------------------------------------------------------------");
    for(Employee emp1: emp){
        System.out.format("%10s %30s %20s ",
                emp1.getName(), emp1.getdateOfJoining(),emp1.getaddress());
        System.out.println();
    }
   
}
}