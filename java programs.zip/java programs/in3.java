class Member{
  String name;
  int age;
  String number;
  String address;
  int salary;

  public void printSalary(){
    System.out.println(salary);
  }

}

class Employee extends Member{
  String specialization;
}
class Manager extends Member{
  String department;
}

class In3{
  public static void main(String[] args){
    Employee e = new Employee();
    System.out.println(e.name="theju");
    System.out.println(e.age=23);
    System.out.println(e.number="9876521");
    System.out.println(e.address="chennai");
    System.out.println(e.salary=3445);
    e.printSalary();
    System.out.println(e.specialization="cse");
    
    
    Manager m = new Manager();
    System.out.println(m.name="prathyu");
    System.out.println(m.age=43);
    System.out.println(m.number="9876556");
    System.out.println(m.address="chennai");
    System.out.println(m.salary=3945);
    e.printSalary();
    System.out.println(m.department="des");
    
    
  }
}									



