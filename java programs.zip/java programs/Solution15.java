import java.util.*;
class Area{
  int length;
  int breath;
 public void setDim(int l,int b){
    length=l;
    breath=b;
   System.out.println(length*breath);
 }
public void getArea(){
   Scanner sc=new Scanner(System.in); 
   System.out.println("Enter length of the rectangle");
   int length=sc.nextInt();
   System.out.println("Enter length of the rectangle");
  int breath=sc.nextInt();
  System.out.println(length*breath);
}
}
public class Solution15{
public static void main(String args[]){
  Area a=new Area();
     a.setDim(10,20);
 Area a1=new Area();
   a1.getArea(); 
}  
}