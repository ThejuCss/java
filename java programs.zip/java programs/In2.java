class Parent{
  private void parent(){
    System.out.println("This is parent class");
  }
}

class Child extends Parent{
  public void child(){
    System.out.println("This is child class");
  }
}

public class In2{
  public static void main(String[] args){
    Parent p = new Parent();
    Child c = new Child();
    p.parent();
    c.child();
  }
}			