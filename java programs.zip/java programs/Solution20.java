
import java.io.*;
public class StuArr
{
	int rollno,x,y,z;
	float avg;
public static double average(double x, double y, double z)
{
        return (x + y + z) / 3;
}
void enter() throws IOException
{
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
  System.out.println("Enter your roll no");
   rollno =Integer.valueOf(br.readLine());
  System.out.print("Input the first number: ");
    x =Integer.valueOf(br.readLine());
  System.out.print("Input the second number: ");
    y = Integer.valueOf(br.readLine());
  System.out.print("Input the third number: ");
    z=Integer.valueOf(br.readLine());
}
        
void display()		
{		 
  System.out.print("The average value is " + average(x, y, z)+"\n" );		
}
}
public class Solution20{	
public static void main(String... args) throws Exception
{	
   StuArr[] arr = new StuArr[8];
	for(int i=0; i<arr.length; i++)	
	{
	arr[i] = new StuArr();
	}
	for(int j=0; j<arr.length; j++)
	{
	arr[j].enter();
	arr[j].display();
	}
	for(StuArr e : arr)
	{
	e.display();
	}
}
}

