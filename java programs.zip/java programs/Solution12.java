class Triangle{
  int a,b,c;
Triangle(){
      this.a=a;
      this.b=b;
      this.c=c;
  }
  public double getArea(){
    double s = (a+b+c)/2.0;
     s = s*(s-a)*(s-b)*(s-c);
     return Math.sqrt(s);
  }
  public double getPerimeter(){
    return (a+b+c)/2.0;
  }
}

public class Solution12{
  public static void main(String[] args){
    Triangle t = new Triangle();
    t.a = 3;
    t.b = 4;
    t.c = 5;
    System.out.println("Area of triangle is "+t.getArea());
    System.out.println("perimeter of triangle is "+t.getPerimeter());
  }
}				
    
    