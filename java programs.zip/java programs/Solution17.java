import java.util.Scanner;
public class Average {
double x,y,z;
public static double average(double x, double y, double z)
    {
        return (x + y + z) / 3;
    }
}
class Solution17
{
 public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Input the first number: ");
         x = in.nextDouble();
        System.out.print("Input the second number: ");
         y = in.nextDouble();
        System.out.print("Input the third number: ");
         z = in.nextDouble();
        System.out.print("The average value is " + average(x, y, z)+"\n" );
    }
}
