import java.util.*;
public class Solution5{
    public static void main(String args[]) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter n value");
        int n=sc.nextInt();
        int square=n*n;
        System.out.println("square of a number "+square);
    }
}
