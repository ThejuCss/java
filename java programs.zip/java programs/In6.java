class Shape
{
    
  void shape()
    
  {
        
    System.out.println("This is shape");
    
  }

}

class Rectangle extends Shape{
 
  void rectangle()
  {
    
    System.out.println("This is rectangle shape.");
  
  }

}

class Circle extends Shape
{
  
  void  circle()
  {
    
   System.out.println("This is circle shape.");
  
  }

}

class Square extends Rectangle
{
    
  void square()
    
  {
        
    System.out.println("square is a rectangle");
    
  }

}

public class In6{
  
public static void main(String[] args){
     
  Square s=new Square();
    
   s.rectangle();
     
   s.shape();

}

}