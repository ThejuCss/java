import java.util.*;
public class Area1{
 static int length;
  static int breath;
Area1(int length,int breath)
{
    this.length=length;
    this.breath=breath;
}
public void returnArea(){
  Scanner sc=new Scanner(System.in); 
   System.out.println("Enter length of the rectangle");
   int length=sc.nextInt();
   System.out.println("Enter length of the rectangle");
  int breath=sc.nextInt();
  System.out.println(length*breath);
}
}
class Solution16{
public static void main(String args[]){

 Area1 a1=new Area1(length,breath);
   a1.returnArea(); 
}  
}