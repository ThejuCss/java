abstract class Parent
{
  public abstract void message();
}
  class SubClass1 extends Parent
  {
    public void message()
    {
     System.out.println("this is first subclass");
    }
  }
  class SubClass2 extends Parent
  {
   public void message()
    {
     System.out.println("this is second subclass");
    }
   }
public class In10{
 public static void main(String args[])
 {
   SubClass1 sc1=new SubClass1();
   SubClass2 sc2=new SubClass2();
   
  sc1.message();
  sc2.message();
 }
}