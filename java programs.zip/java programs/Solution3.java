import java.util.*;
public class Solution3{
    public static void main(String args[]) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your name");
        String name=sc.nextLine();
        System.out.println("Enter your roll number");
        int rollNumber=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter your field of interest");
        String fieldOfInterest=sc.nextLine();
        
        System.out.println("Hey, my name is: " +name+ " and my roll number is " +rollNumber+".My field of interest are " +fieldOfInterest);
    }  
}
