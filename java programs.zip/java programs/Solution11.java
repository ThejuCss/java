class Student{
   int rollnumber;
   int phonenumber;
   String address;  
}
class Solution11{
  public static void main(String args[]){
   Student sam=new Student();
     sam.rollnumber=1;
     sam.phonenumber=234567;
     sam.address="chennai";
     System.out.println("rollnumber is" +sam.rollnumber+ "phonenumber is" +sam.phonenumber+ "address is" +sam.address);
   Student ram=new Student();
     ram.rollnumber=2;
     ram.phonenumber=345678;
     ram.address="chennai";
     System.out.println("rollnumber is" +ram.rollnumber+ "phonenumber is" +ram.phonenumber+ "address is" +ram.address);
   }
}