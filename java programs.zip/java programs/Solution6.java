import java.util.*;
public class Solution6{
    public static void main(String args[]) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter first string");
        String s1=sc.nextLine();
        System.out.println("Enter second string");
        String s2=sc.nextLine();
        System.out.println("final string is "+ s1+s2);
    }
}