import java.util.*;
public class Solution1{
    public static void main(String args[]) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter first number");
        int a=sc.nextInt();
        System.out.println("Enter second number");
        int b=sc.nextInt();
        int sum=a+b;
        System.out.println("sum of two numbers is: "+sum);
        int mul=a*b;
        System.out.println("multiplication of two numbers is :"+mul);
    }
}

