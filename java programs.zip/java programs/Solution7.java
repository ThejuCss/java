
import java.util.*;
public class Solution7{
    public static void main(String args[]) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter first number");
        int n1=sc.nextInt();
        System.out.println("Enter second number");
        int n2=sc.nextInt();        
        System.out.println("Enter third number");
        int n3=sc.nextInt();
        if(n1==n2 && n1==n3 && n2==n1 && n2==n3 && n3==n1 && n3==n2)
        {
            System.out.println("equal");
        }
        else
        {
            System.out.println("not equal");
        }
    }
}