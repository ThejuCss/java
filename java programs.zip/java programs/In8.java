abstract class Bank{    
abstract int getBalance();    
}    
class BankA extends Bank{    
int getBalance(){
  return 10;
 }    
}    
class BankB extends Bank{    
int getBalance(){
 return 20;
 }    
} 
class BankC extends Bank{    
int getBalance(){
 return 30;
}    
} 
   
    
class In8{    
public static void main(String args[]){    
Bank b;  
BankA b1=new BankA();  
System.out.println("Balance is: "+b1.getBalance());    
BankB b2=new BankB();  
System.out.println("Balance is: "+b2.getBalance()); 
BankC b3=new BankC();  
System.out.println("Balance is: "+b3.getBalance());    
}}    