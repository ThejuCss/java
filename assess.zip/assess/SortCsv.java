import java.io.*;
import java.util.*;
class Sortcsv{

public static void main(String args[])throws Exception
{
String csv="C:/Users/css119008/Downloads/LoadRun_2 Hps.csv";
BufferedReader br= new BufferedReader(new java.io.FileReader(csv));
String line=" ";
TreeMap<Double,String> treemap = new TreeMap<Double,String>();
try {
    br.readLine();
    while((line = br.readLine()) != null) {
       treemap.put(Double.parseDouble(line.split(",")[1]),line);
    }
} catch (IOException e) {
    e.printStackTrace();
}
double sum=0;
double avg=0;
for(Map.Entry<Double,String> entry : treemap.entrySet()) {
  Double key = entry.getKey();
  sum=sum+entry.getKey();
  avg=sum/treemap.size();
}
System.out.println("average value is: "+ avg);
System.out.println("minimum value is: "+ treemap.firstKey());
System.out.println("maximum value is: "+ treemap.lastKey());
int count = 1;
for(Object key : treemap.keySet())
{
    if(count == 16)
        System.out.println("16th min value is:"+key);
    count++;
}

}
}