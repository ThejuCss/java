class Student{
  String name;
  int roll_num;
}
class A{
  public static void main(String args[])
  {
    Student s=new Student();
    s.name="jhon";
    s.roll_num=22;
    System.out.println("name is" + s.name +  "and roll_num is" +s.roll_num);
  }
} 
