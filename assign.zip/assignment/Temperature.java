import java.util.*;
class Temperature{
public static void main(String args[]){
int fahrenheit,celisus;
Scanner sc=new Scanner(System.in);
System.out.println("enter your choice");
int ch=sc.nextInt();
switch(ch){
case 1:
System.out.println("enter temperature in fahrenheit");
double f=sc.nextInt();
f=(f-32)*0.5556;
System.out.println("converted temperature from fahrenheit to celisus"+f);
break;
case 2:
System.out.println("enter temperature in celisus");
double c=sc.nextInt();
c=(c*1.8)+32;
System.out.println("converted temperature from celisus to fahrenheit "+c);
}
}
}
