import java.util.*;
abstract class Marks
{
  public abstract int getPercentage();
}
class StudentA{
 int a,b,c,total;
 float percentage;
 public void getPercentage()
 {
 Scanner sc=new Scanner(System.in);  
System.out.println("enter marks subject1");
   a=sc.nextInt();
System.out.println("enter marks subject2");
   b=sc.nextInt();
System.out.println("enter marks subject3");
   c=sc.nextInt();
   total=a+b+c;
  percentage=(total)/3*100;
  System.out.println(percentage);
 }
}
class StudentB{
 int a,b,c,d,total,percentage;
 public void getPercentage()
 {
  Scanner sc=new Scanner(System.in);
  System.out.println("enter marks subject1");
   a=sc.nextInt();
  System.out.println("enter marks subject2");
   b=sc.nextInt();
  System.out.println("enter marks subject3");
   c=sc.nextInt();
  System.out.println("enter marks subject4");
   d=sc.nextInt();
   total=a+b+c+d;
   System.out.println(total);
  percentage=(total)/4*100;
  
  System.out.println(percentage);
 }
}
class Stud{
 public static void main(String args[]){
 StudentA a=new StudentA();
 a.getPercentage();
 StudentB b=new StudentB();
 b.getPercentage();
 
 }
}
