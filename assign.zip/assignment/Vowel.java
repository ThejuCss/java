class Vowel
{
  public static void main(String args[]){
  String s=args[0];
  for(int i=0;i<args.length;i++){
  char x=s.charAt(i);
  if(x=='a' ||x=='e' || x=='i' ||x=='o' || x=='u')
  System .out.println("vowel");
  else
  System.out.println("consonent");
  }
  }
}