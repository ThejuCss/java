import java.io.*;
class Account
{
 	long accountNumber;
 	float balance;
 	float monthlyInterestRate;
 
	public void setAccountNumber(long accountNumber)
 	{
   		this.accountNumber=accountNumber;
 	}
 
	public long getAccountNumber()
 	{
   		return accountNumber;
  	}
 
	public void setBalance(float balance)
 	{ 
   		this.balance=balance;
 	} 
 	
	public float getBalance()
 	{
   		return balance;
 	}
 
	public void setMonthlyInterestRate(float monthlyInterestRate)
 	{
   		this.monthlyInterestRate=monthlyInterestRate;
 	}
 
	public float getmonthlyInterestRate()
 	{
  		return monthlyInterestRate;
 	}

	public void printInfo()
	{
  		System.out.println("accountnumber" +accountNumber);
  		System.out.println("montlyInterestRate" +monthlyInterestRate);
  		System.out.println("balance" +balance);
	}
}
class Checkings extends Account
{
 	float withdraw;

	Checkings()
	{
		super();
	}
 
	public void setWithDraw(float withdraw)
 	{
    		this.withdraw=withdraw;
 	}
 
	public float getWithDraw()
 	{
  		return withdraw;
 	}
 

 	public void print()
	{
 		System.out.println("withdraw" +withdraw);
		float val=super.getBalance()-withdraw;
 		System.out.println("Balance amount after withdraw" +val);
	}
}
class Savings extends Account
{
  	float deposit;
 
	public void setDeposit(float deposit)
 	{
   		this.deposit=deposit;
 	}
 
	public float getDeposit()
 	{
   		return deposit;
 	}
 

  	public void print()
  	{
   		System.out.println("deposit"+deposit);
		float val=super.getBalance()+deposit;
   		System.out.println("amount after deposit"+val);
  	}
}
public class Acc
{
 	public static void main(String args[]) throws IOException
 	{
   
 	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
   	Account acc=new Account();
   	System.out.println("Enter balance");
   	float balance1=Float.valueOf(br.readLine());
   	acc.setBalance(balance1);
   	acc.printInfo();
   
   	Checkings check=new Checkings();
	System.out.println("Enter balance");
   	float balance2=Float.valueOf(br.readLine());
   	check.setBalance(balance2);

   	System.out.println("enter withdraw amount");
    	float withdraw=Float.valueOf(br.readLine());
    	check.setWithDraw(withdraw);
    	check.print();
   	

    	Savings depo=new Savings();

	System.out.println("Enter balance");
   	float balance3=Float.valueOf(br.readLine());
   	depo.setBalance(balance3);

    	System.out.println("enter deposit amount");
    	float deposit=Float.valueOf(br.readLine());
    	depo.setDeposit(deposit);
    	depo.print();
    	
}

}
  
