class Account{
 long accountNumber;
 float balance;
 float montlyInterestRate;
 public void setAccountNumber(long accountNumber);
 {
   this.accountNumber=accountNumber;
 }
 public long getAccountNumber();
 {
   return accountNumber;
 }
public void setBalance(float balance);
 {
   this.balance=balance;
 } 
public float getBalance();
 {
   return balance;
 }
 public void setMonlyInterestRate(float montlyInterestRate);
 {
   this.montlyInterestRate=montlyInterestRate;
 }
 public float getmontlyInterestRate();
 {
   return monthlyInterestRate;
 }
public void printInfo(){
  System.out.println("accountnumber" +AccountNumber);
  System.out.println("montlyInterestRate" +montlyInterestRate);
  System.out.println("balance" +balance);
}
}
class Checkings extends Account{
 float withdraw;
 public void setWithDraw(float withdraw)
 {
    this.withdraw=withdraw;
 }
 public float getWithDraw()
 {
  return withdraw;
 }
 public void checking(){
  float balanceAmount=withdraw-amount;
 }
 public void print(){
 System.out.println("withdraw" +withdraw);
 System.out.println("checking amount after withdraw" +balanceAmount);
}
}
class Savings extends Account{
  float deposit;
 public void setDeposit(float deposit)
 {
   this.deposit=deposit;
 }
 public float getDeposit()
 {
   return deposit;
 }
 public void savings()
 {
   float balanceAmount=deposit+balanceAmount;
 }
  public void print()
  {
   System.out.println("deposit"+deposit);
   System.out.println("amount after deposit"+balanceAmount);
  }
}
public class Acc{
 public static void main(String args[])
 {
  Account acc=new Account();
  public void setBalance(float balance){
  this.balance=balance;
  }
  checking check=new checking();
  public void setWithDraw(float withdraw)
  {
   this.withdraw=withdraw;
  }
  public float getWithDraw()
  {
    return withdraw();
  }
  checking.print();
}
  deposit depo=new deposit();
  {
    public void setDeposit(float deposit)
  {
   this.deposit=deposit;
  }
  public float getDeposit()
  {
    return Deposit();
  }
 depo.print();
}
  
}
}