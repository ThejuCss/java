
class Person
{
   String name;
   String address;
   
   Person()
   {
   
   }
   
   Person(String name,String address)
   {
        this.name=name;
        this.address=address;
   }
   
  void display()
  {
      
       System.out.println("Name is" +name);
       System.out.println("Address is "+address);
  }
}
class Employee extends Person 
{
  Integer empId;
  String companyName;
   
  Employee()
  {
    super();
  }
  Employee(String name,String address,Integer empId,String companyName)
  {
     super(name,address);
     this.empId=empId;
     this.companyName=companyName;
  }
 void display()
 {
  super.display();
   System.out.println("employee id is"+empId);
   System.out.println("company name is"+companyName);
 }
}
public class MainProgram{
public static void main(String args[]){
  Person p=new Person("theju","chennai"); 
  Employee e=new Employee("theja","chennai",11234,"csscorp");
  p.display();
  e.display();
}
}
   