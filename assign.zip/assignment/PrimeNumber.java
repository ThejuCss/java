class PrimeNumber{
         public static void main(String args[]){
          int n1,n2,count=0,i,j;
          for(int a=0;a<args.length;a++) 
	  { 
            System.out.println("enter lower bound number");
             n1=Integer.parseInt(args[0]);
            System.out.println("enter upper bounnd number");
             n2=Integer.parseInt(args[1]);
             for(i = n1; i <= n2; i++)
		{
			for( j = 2; j < i; j++)
			{
				if(i % j== 0)
				{
					count = 0;
					break;
				}
				else
				{
					count = 1;
				}
			}
			if(count == 1)
			{
				System.out.println(i);
			}
                 }
              }
           }
        }