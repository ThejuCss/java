import java.util.*;
class TriangleP{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
TriangleP(int a,int b,int c){
this.a=a;
this.b=b;
this.c=c;
}
TriangleP t=new Trianglep(4,5,6);


double area=0.5*a*b;
int perimeter=a+b+c;
System.out.println(area);
System.out.println(perimeter);
}
}