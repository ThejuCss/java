abstract class Shape
{
  abstract void area();
}
class Square extends Shape
{
  int side;
  
   Square(int side)
   {
    this.side=side;
   }
   
   public void area()
   {
     System.out.println("Area is: "+side*side);
   }
}
class Circle extends Shape
{
  float radius;
  
  Circle(int radius)
  {
   this.radius=radius;
  }
  public void area()
  {
    System.out.println("Area is:"+3.14*radius*radius);
  }
}
class Rectangle extends Shape
{
  int length,breadth;
  
  Rectangle(int length,int breadth)
  {
    this.length=length;
    this.breadth=breadth;
  }
  public void area()
 {
  System.out.println("Area is:"+length*breadth);
 }
}
 public class Area{
 public static void main(String args[])
 {
 Square s1=new Square(20);
 Circle c=new Circle(4);
 Rectangle r=new Rectangle(2,4);
 s1.area();
 c.area();
 r.area();
 }
}  