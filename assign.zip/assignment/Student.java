class Student{
   String name="jhon";
   Integer roll_no=2; 
   
public static void main(String args[])
{
 Student s1=new Student();
 
}
}