class Number{
public static void main(String args[]){
int i=10;
ABC a1=new ABC();
Integer num=Integer.valueOf(i);
a1.display(num);
A a2=new A();
Float f=Float.valueOf(i);
a2.display(f);

}
}
class ABC{
int display(Integer var){
System.out.println(var);
System.out.println("inside main");
System.out.println("var instanceof Integer");
return var;
}
}
class A{
float display(Float var){
System.out.println(var);
System.out.println("inside main");
System.out.println("var instanceof Float");
return var;
}
}