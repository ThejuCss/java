import java.util.*;
class StringReverse{
    public static void main(String args[]){
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the string");
      String s=sc.next();
      String rev="";
      char ch[]=s.toCharArray();
      for(int i=ch.length-1;i>=0;i--){  
      rev += ch[i];
     }
 System.out.println(rev);
}
}