import java.util.*;
class IndividualDigits{
       public static void main(String args[]){
          Scanner sc=new Scanner(System.in);
          System.out.println("enter the number");
          int n=sc.nextInt();
          while(n!=0)
          {
           int n1=n/1000000%10;
           int n2=n/10000%10;
           int n3=n/1000%10;
           int n4=n/100%10;
           int n5=n/10%10;
           int n6=n%10;
          }
          int arr=new int[n1,n2,n3,n4,n5,n6];
          System.out.println(arr);
         }
      }

                       