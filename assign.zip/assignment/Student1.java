class Student1{
  String name;
  Integer roll_number;
  int phonenumber;
  String address;
 Student1 s=new Student1(name,roll_number,phonenumber,address);
public static void main(String args[]){
 Student1 s1=new Student1("jhon",1,23456,"chennai");
 Student1 s2=new Student1("sam",2, 23456,"chennai");
System.out.println(s1);
System.out.println(s2);
}
}