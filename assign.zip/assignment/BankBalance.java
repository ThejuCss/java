
abstract class Bank
 {
  abstract int getBalance();
}
        
public void setbalance(float balance)	
{
  this.balance=balance;
} 
public float getbalance()
 {
   return balance;
 }
class BankA extends Bank
{
 public int getBalance()
 {
  System.out.println("balance"+getbalance);
 }
}
class BankB extends Bank
{
 public int getBalance()
 {
 System.out.println("balance"+getbalance);
 }
}
class BankC extends Bank
{
 public int getBalance()
 {
 System.out.println("balance"+getbalance);
 }
}
class BankBalance
{
 public static void main(String args[])
 {
  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
   	Bank b=new Bank();
   	System.out.println("Enter balance");
   	float balance1=Float.valueOf(br.readLine());
   	acc.setBalance(balance1);
     BankA a=new BankA();
      a.getBalance();
    BankB b=new BankB();
      b.getBalance();
    BankC b=new BankC();
     c.getBalance(); 
 }
}