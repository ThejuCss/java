class Employee{
  String name;
  String doj;
  String address;
 Employee(String name,String doj,String address)
 {
    this.name=name;
    this.doj=doj;
    this.address=address;
 }
 void display()
 {
   System.out.println("Employee name is"+name);
   System.out.println("doj is"+doj);
   System.out.println("address is"+address);
 }
 }
 public class Main{
   public static void main(String args[])
   {
      Employee e1=new Employee("sam","12-2-19","chennai");
      Employee e2=new Employee("ram","12-3-19","chennai");
      Employee e3=new Employee("raj","12-4-19","chennai");
       
      e1.display();
      e2.display();
      e3.display();
  }
}
