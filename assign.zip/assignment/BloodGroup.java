import java.io.*;
public class BloodGroup{
 public static void main(String args[])throws Exception{
   InputStreamReader r=new InputStreamReader(System.in);   
   BufferedReader br=new BufferedReader(r);      
  System.out.println("enter your name");
  String s=br.readLine();
   System.out.println("welcome"+s);
  int a=Integer.parseInt("75");
  if(a>=18)
  System.out.println("enter your blood group");
  String b=br.readLine();
  if(b=="AB"){
   System.out.println("your blood is not accepted");
   }
   else{
   System.out.println("you can donate blood");
}
}
}