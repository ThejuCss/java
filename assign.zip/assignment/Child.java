abstract class Parent
{
   public void message()
   {
     class SubClass1
     {
       public void message()
       {
        System.out.println("This is first subclass");
        }
      }
       class SubClass2
       {
         public void message()
         {
           System.out.println("This is second subclass");
         }
       }
 }
 class Child extends Parent
 {  
  public static void main(String args[])
  {
    Student s1=new Student();
      s1.message();
    Student s2=new Student();
       s2.message();
   }
  }
 }
  
        
   