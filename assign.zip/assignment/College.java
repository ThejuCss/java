import java.util.*;
class Teacher{
   String designation="teacher";
   String college="aditya";
  Teacher(String designation,String college)
  {
     this.designation=designation;
     this.college=college;
  }
  
 void work()
 {
  System.out.println("desgination is"+designation);
  System.out.println("college is"+college);
  System.out.println("Teaching");
 }
 
class SubjectTeacher extends Teacher{
  String subject;
  SubjectTeacher(String designation,String college,String subject)
  {
     this.designation=designation;
     this.college=college;
     this.subject=subject;
  }
   void work()
   {
    System.out.println("desgination is"+designation);
    System.out.println("college is"+college);
    System.out.println("Teaching subject"+subject);
   }
}
}
public class College{
 public static void main(String args[])
 {
   Teacher t1=new Teacher("teacher","aditya");
   t1.work();
  SubjectTeacher s1=new SubjectTeacher("teacher","aditya","maths");  
   s1.work();
 }
}
 