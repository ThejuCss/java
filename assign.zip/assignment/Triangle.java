import java.util.*;
class Triangle{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
Triangle t=new Triangle();
System.out.println("enter side value of triangle");
int a=sc.nextInt();
System.out.println("enter base value of triangle");
int b=sc.nextInt();
System.out.println("enter side value of triangle");
int c=sc.nextInt();
double area=0.5*a*b;
int perimeter=a+b+c;
System.out.println(area);
System.out.println(perimeter);
}
}